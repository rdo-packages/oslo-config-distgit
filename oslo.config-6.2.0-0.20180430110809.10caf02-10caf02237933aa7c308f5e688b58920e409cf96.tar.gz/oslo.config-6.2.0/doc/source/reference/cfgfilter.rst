--------------------
The cfgfilter Module
--------------------

.. automodule:: oslo_config.cfgfilter
