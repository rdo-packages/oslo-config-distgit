------------
File Parsing
------------

.. autoclass:: oslo_config.iniparser.BaseParser

.. autoclass:: oslo_config.cfg.ConfigParser
   :members: parse
