---------------------------
Option Types and Validation
---------------------------

.. automodule:: oslo_config.types
   :members:
